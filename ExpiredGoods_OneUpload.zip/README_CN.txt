过期商品换货登记 v1.0（Android）

核心工作流程
1. 拍照或选相册，使用自己的 OpenAI API Key 做 AI 商品识别。
2. 照片中不同 SKU 按商品大类（面包、酸奶、香肠等）自动分类，然后按品牌排列。
3. AI 预览界面人工核对商品名、品牌、规格、数量、单位、有效期并保存。
4. 在“经销商换货”中新建任意名称的经销商，例如 Bimbo / 乳品 / 肉制品。
5. 回到“商品分类”，勾选要换货的商品，选择“复制到经销商”或“剪切到经销商”，然后指定经销商。
6. 经销商栏目里勾选“已更换”，还可修改数量、复制文字换货单或分享。

重要行为
- 品类和品牌是商品自身的自动归档；经销商完全由用户创建、选择，AI 绝不擅自分配。
- 剪切：隐藏商品分类中的待分配原始记录，转入经销商换货清单；原始记录在 SQLite 中保留。
- 移除剪切来的换货记录：该商品自动回到“商品分类”。
- 复制：经销商多一条记录，商品分类中仍然保留原来的记录。重复复制会生成多条，操作前请核对。
- 同一照片可以识别多个不同商品，识别结果可取消勾选或逐项修改数量。
- API 无法辨识日期时应保持空白，不能假设有效期准确；保存前必须人工核对。
- 不联网时依然可以手动登记、查询清单和勾选已更换。
- 数据及照片默认仅保存在手机；只有 AI 识别时向 OpenAI 传送所选照片。
- API Key 以 Android Keystore AES-GCM 本地加密；不会写进源代码。
- 默认模型 gpt-6-luna（适合费用敏感的短任务，可在设置页自由改成账号有权限的视觉模型）。
- CSV 导出包括原始商品记录和经销商换货明细，但不包含照片。卸载 App 会删除本地数据。

重要：Github 网页上传一个 ZIP，并不会自动解压变成工程。
本工程为“单 ZIP 上传 + 已安装 GitHub Actions 工作流”的方式：

首次安装：
1. 在 GitHub 创建空仓库（建议名 ExpiredGoodsApp）。
2. 通过 Add file -> Create new file，在文件名填写 .github/workflows/build-apk.yml。
3. 将随附的 build-apk_ExpiredGoods_v1.txt 全部文字粘贴为文件内容，然后 Commit。
4. 通过 Add file -> Upload files，上传 ExpiredGoods_OneUpload.zip（不要解压）。Commit。
5. 打开 Actions -> Build Expired Goods APK -> 最新一次执行 -> Artifacts -> ExpiredGoods-APK。
6. 下载并解压 GitHub Artifact，在手机安装 app-debug.apk。

以后更新版本：只需要替换仓库根目录的 ExpiredGoods_OneUpload.zip，GitHub Actions 自动编译新版本。
如仓库默认分支名不是 main 或 master，需调整 workflow 中的 branches，或在 Actions 中手动 Run workflow。

环境：Android 8.0+；构建使用 Android Gradle Plugin 8.7.3，Gradle 8.9，JDK 17，compileSdk 35。
这是可编译的源码工程，上传 GitHub Actions 编译为 APK。尚未在实际手机上完成安装运行测试。
