package com.stock.expiry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class Store extends SQLiteOpenHelper {
    public static final class Product {
        public long id;
        public String name, category, brand, spec, unit, expiry, note, photo;
        public int qty, status;
    }
    public static final class Dealer {
        public long id;
        public String name, note;
    }
    public static final class Exchange {
        public long id, productId, dealerId;
        public String name, category, brand, spec, unit, expiry, photo, note, mode;
        public int qty;
        public boolean done;
    }

    public Store(Context context) { super(context, "expiry_goods_v1.db", null, 1); }
    @Override public void onConfigure(SQLiteDatabase db) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL, brand TEXT NOT NULL, spec TEXT, qty INTEGER NOT NULL DEFAULT 1, unit TEXT, expiry TEXT, note TEXT, photo TEXT, status INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE dealers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, note TEXT, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE exchange_items (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, dealer_id INTEGER NOT NULL REFERENCES dealers(id), name TEXT NOT NULL, category TEXT, brand TEXT, spec TEXT, qty INTEGER NOT NULL DEFAULT 1, unit TEXT, expiry TEXT, photo TEXT, note TEXT, mode TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, done_at INTEGER, FOREIGN KEY(product_id) REFERENCES products(id))");
        db.execSQL("CREATE INDEX exch_dealer ON exchange_items(dealer_id,done)");
        db.execSQL("CREATE INDEX products_category ON products(status,category,brand)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    static String nz(String s) { return s == null ? "" : s.trim(); }
    private static ContentValues productValues(Product p) {
        ContentValues v = new ContentValues();
        v.put("name", nz(p.name).isEmpty()?"未命名商品":nz(p.name));
        v.put("category", nz(p.category).isEmpty()?"其他":nz(p.category));
        v.put("brand", nz(p.brand).isEmpty()?"未识别品牌":nz(p.brand));
        v.put("spec", nz(p.spec)); v.put("qty", Math.max(1,p.qty)); v.put("unit", nz(p.unit).isEmpty()?"件":nz(p.unit));
        v.put("expiry", nz(p.expiry)); v.put("note",nz(p.note)); v.put("photo",nz(p.photo));
        return v;
    }
    public long addProduct(Product p) {
        ContentValues v = productValues(p); v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insertOrThrow("products", null, v);
    }
    public void editProduct(Product p) { getWritableDatabase().update("products", productValues(p), "id=?", new String[]{String.valueOf(p.id)}); }
    public void deleteProduct(long id) {
        // A registered item is retained if it has exchange history; avoid broken references.
        SQLiteDatabase db = getWritableDatabase();
        try (Cursor c=db.rawQuery("SELECT COUNT(*) FROM exchange_items WHERE product_id=?",new String[]{""+id})) {
            if(c.moveToFirst() && c.getInt(0)>0) throw new IllegalStateException("此商品已加入换货单，请先删除对应换货记录");
        }
        db.delete("products","id=?",new String[]{""+id});
    }
    private static Product readProduct(Cursor c) {
        Product p = new Product();
        p.id=c.getLong(0);p.name=c.getString(1);p.category=c.getString(2);p.brand=c.getString(3);
        p.spec=c.getString(4);p.qty=c.getInt(5);p.unit=c.getString(6);p.expiry=c.getString(7);
        p.note=c.getString(8);p.photo=c.getString(9);p.status=c.getInt(10);return p;
    }
    public List<Product> products(boolean onlyAvailable) {
        List<Product> out = new ArrayList<>();
        String sql="SELECT id,name,category,brand,spec,qty,unit,expiry,note,photo,status FROM products"+
                (onlyAvailable?" WHERE status=0":"")+" ORDER BY category COLLATE NOCASE, brand COLLATE NOCASE, created_at DESC";
        try(Cursor c=getReadableDatabase().rawQuery(sql,null)) { while(c.moveToNext())out.add(readProduct(c)); }
        return out;
    }
    public Product getProduct(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,category,brand,spec,qty,unit,expiry,note,photo,status FROM products WHERE id=?",new String[]{""+id})) {
            return c.moveToFirst()?readProduct(c):null;
        }
    }

    public long addDealer(String name, String note) {
        ContentValues v=new ContentValues();v.put("name",name.trim());v.put("note",nz(note));v.put("created_at",System.currentTimeMillis());
        return getWritableDatabase().insertOrThrow("dealers",null,v);
    }
    public void editDealer(long id,String name,String note){
        ContentValues v=new ContentValues();v.put("name",name.trim());v.put("note",nz(note));
        getWritableDatabase().update("dealers",v,"id=?",new String[]{""+id});
    }
    public boolean deleteDealerIfEmpty(long id) {
        SQLiteDatabase db=getWritableDatabase();
        try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM exchange_items WHERE dealer_id=?",new String[]{""+id})){
            if(c.moveToFirst() && c.getLong(0)>0)return false;
        }
        return db.delete("dealers","id=?",new String[]{""+id})>0;
    }
    public List<Dealer> dealers(){
        ArrayList<Dealer> list=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,note FROM dealers ORDER BY name COLLATE NOCASE",null)){
            while(c.moveToNext()){ Dealer d=new Dealer();d.id=c.getLong(0);d.name=c.getString(1);d.note=c.getString(2);list.add(d);}
        }return list;
    }

    public int transfer(List<Long> ids, long dealerId, boolean cut) {
        SQLiteDatabase db=getWritableDatabase(); int count=0;
        db.beginTransaction();
        try {
            for(long id:ids){
                Product p=getProduct(id);if(p==null || p.status!=0)continue;
                ContentValues v=new ContentValues();v.put("product_id",p.id);v.put("dealer_id",dealerId);
                v.put("name",p.name);v.put("category",p.category);v.put("brand",p.brand);v.put("spec",p.spec);
                v.put("qty",p.qty);v.put("unit",p.unit);v.put("expiry",p.expiry);v.put("note",p.note);v.put("photo",p.photo);
                v.put("mode",cut?"CUT":"COPY");v.put("created_at",System.currentTimeMillis());
                db.insertOrThrow("exchange_items",null,v);
                if(cut){ContentValues upd=new ContentValues();upd.put("status",1);db.update("products",upd,"id=?",new String[]{""+id});}
                count++;
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return count;
    }
    public List<Exchange> exchangeItems(long dealerId){
        List<Exchange> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,product_id,dealer_id,name,category,brand,spec,qty,unit,expiry,photo,note,mode,done FROM exchange_items WHERE dealer_id=? ORDER BY done, category COLLATE NOCASE, brand COLLATE NOCASE, created_at DESC",new String[]{""+dealerId})){
            while(c.moveToNext()){
                Exchange e=new Exchange();e.id=c.getLong(0);e.productId=c.isNull(1)?-1:c.getLong(1);e.dealerId=c.getLong(2);
                e.name=c.getString(3);e.category=c.getString(4);e.brand=c.getString(5);e.spec=c.getString(6);
                e.qty=c.getInt(7);e.unit=c.getString(8);e.expiry=c.getString(9);e.photo=c.getString(10);
                e.note=c.getString(11);e.mode=c.getString(12);e.done=c.getInt(13)==1;out.add(e);
            }
        }return out;
    }
    public void setDone(long id, boolean done) {
        ContentValues v=new ContentValues();v.put("done",done?1:0);
        if(done)v.put("done_at",System.currentTimeMillis());else v.putNull("done_at");
        getWritableDatabase().update("exchange_items",v,"id=?",new String[]{""+id});
    }
    public void changeExchangeQty(long id, int qty){ContentValues v=new ContentValues();v.put("qty",Math.max(1,qty));getWritableDatabase().update("exchange_items",v,"id=?",new String[]{""+id});}
    public void removeExchange(Exchange e) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            db.delete("exchange_items","id=?",new String[]{""+e.id});
            if("CUT".equals(e.mode) && e.productId>0){
                ContentValues v=new ContentValues();v.put("status",0);
                db.update("products",v,"id=?",new String[]{""+e.productId});
            }
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }
}
