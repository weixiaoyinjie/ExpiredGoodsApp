package com.stock.expiry;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class AiClient {
    private AiClient() { }
    private static String readAll(InputStream stream) throws Exception {
        if(stream==null)return "";
        try(InputStream s=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=s.read(b))!=-1)out.write(b,0,n);
            return out.toString("UTF-8");
        }
    }
    public static List<Store.Product> recognize(String key,String model,String path) throws Exception {
        BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(path,o);
        o.inSampleSize=Math.max(1,Math.max(o.outWidth/1600,o.outHeight/1600));o.inJustDecodeBounds=false;
        Bitmap bmp=BitmapFactory.decodeFile(path,o);
        if(bmp==null)throw new Exception("无法读取照片");
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        try{ if(!bmp.compress(Bitmap.CompressFormat.JPEG,82,bos))throw new Exception("照片压缩失败"); }
        finally{bmp.recycle();}
        String dataUrl="data:image/jpeg;base64,"+Base64.encodeToString(bos.toByteArray(),Base64.NO_WRAP);
        JSONObject payload=new JSONObject();payload.put("model",model);
        payload.put("max_completion_tokens",1600);
        if("gpt-6-luna".equals(model))payload.put("reasoning_effort","none");
        payload.put("response_format",new JSONObject().put("type","json_object"));
        JSONArray content=new JSONArray();
        String prompt="你是阿根廷超市的到期/过期商品登记识别助手。分析照片中可以清晰区分的商品，可有多个不同SKU。"+
                "只返回一个JSON对象，格式：{\"products\":[{\"name\":\"原包装商品名称\",\"category\":\"面包\",\"brand\":\"品牌\",\"spec\":\"规格\",\"quantity\":1,\"unit\":\"包\",\"expiry\":\"YYYY-MM-DD或者空字符串\",\"notes\":\"识别备注\"}]}。"+
                "先识别商品大类，再提取品牌。category必须为简体中文，优先使用面包、酸奶、香肠、牛奶、奶酪、饼干、饮料、零食、冷冻食品、罐头、其他等具体类目；不要把酸奶归为牛奶、香肠归为面包。"+
                "品牌保留包装真实名称（西班牙语即可），不得虚构；看不清品牌写未识别品牌。name尽量保留包装语言并加上有用的品种区分。"+
                "quantity只统计清晰可见的同款包装数量，看不出填1，不推测库存。日期必须是明确可读的有效期，"+
                "不要把生产日期当作有效期；不可读时expiry填空并在notes标记'有效期请人工核对'。"+
                "每个不同商品型号一条，不同品牌分开，最多返回12条。不要猜测经销商。只返回JSON，不要markdown。";
        content.put(new JSONObject().put("type","text").put("text",prompt));
        content.put(new JSONObject().put("type","image_url").put("image_url",new JSONObject().put("url",dataUrl).put("detail","high")));
        payload.put("messages",new JSONArray().put(new JSONObject().put("role","user").put("content",content)));
        HttpURLConnection conn=(HttpURLConnection)new URL("https://api.openai.com/v1/chat/completions").openConnection();
        try {
            conn.setRequestMethod("POST");conn.setConnectTimeout(20000);conn.setReadTimeout(60000);
            conn.setRequestProperty("Authorization","Bearer "+key);conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
            conn.setDoOutput(true);
            try(OutputStream os=conn.getOutputStream()){os.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
            int status=conn.getResponseCode();String raw=readAll(status>=200&&status<300?conn.getInputStream():conn.getErrorStream());
            if(status<200||status>=300){
                String message=raw;
                try{message=new JSONObject(raw).getJSONObject("error").optString("message",raw);}catch(Exception ignored){}
                throw new Exception("API 错误 "+status+"："+message);
            }
            JSONObject result=new JSONObject(raw);
            JSONArray choices=result.getJSONArray("choices");
            if(choices.length()==0)throw new Exception("AI 没有返回识别结果");
            String body=choices.getJSONObject(0).getJSONObject("message").optString("content","");
            if(body.trim().startsWith("```")){body=body.replaceAll("(?s)^```(?:json)?\\s*","").replaceAll("\\s*```$","");}
            JSONArray products=new JSONObject(body).getJSONArray("products");
            ArrayList<Store.Product> list=new ArrayList<>();
            for(int i=0;i<products.length()&&i<12;i++){
                JSONObject j=products.getJSONObject(i);Store.Product p=new Store.Product();
                p.name=j.optString("name","未命名商品").trim();
                p.category=normalizeCategory(j.optString("category","其他"));
                p.brand=j.optString("brand","未识别品牌").trim();
                if(p.brand.isEmpty()||p.brand.equalsIgnoreCase("null"))p.brand="未识别品牌";
                p.spec=j.optString("spec","");p.qty=Math.max(1,Math.min(99999,j.optInt("quantity",1)));
                p.unit=j.optString("unit","件");p.expiry=j.optString("expiry","");p.note=j.optString("notes","");
                if(!p.name.isEmpty())list.add(p);
            }
            if(list.isEmpty())throw new Exception("没有识别到可登记商品。请换清晰照片或手动登记");
            return list;
        }finally{conn.disconnect();}
    }
    public static String normalizeCategory(String s) {
        if(s==null)return "其他";String t=s.trim();String lc=t.toLowerCase();
        if(t.contains("酸奶")||lc.contains("yogur"))return "酸奶";
        if(t.contains("面包")||lc.contains("pan ")||lc.equals("pan")||lc.contains("bread")||lc.contains("lactal"))return "面包";
        if(t.contains("香肠")||lc.contains("salchicha")||lc.contains("chorizo")||lc.contains("vienesa"))return "香肠";
        if(t.contains("牛奶")||lc.contains("leche"))return "牛奶";
        if(t.contains("奶酪")||lc.contains("queso"))return "奶酪";
        if(t.contains("饼干")||lc.contains("gallet"))return "饼干";
        if(t.contains("饮料")||lc.contains("gaseosa")||lc.contains("bebida")||lc.contains("jugo"))return "饮料";
        if(t.contains("零食")||lc.contains("snack"))return "零食";
        if(t.contains("冷冻")||lc.contains("congelad"))return "冷冻食品";
        if(t.contains("罐头")||lc.contains("conserva"))return "罐头";
        return t.isEmpty()?"其他":t;
    }
}
