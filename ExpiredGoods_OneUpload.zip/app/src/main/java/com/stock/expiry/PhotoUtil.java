package com.stock.expiry;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;

public final class PhotoUtil {
    private PhotoUtil() { }
    public static String importPhoto(Context context, Uri uri) throws Exception {
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        try(InputStream s=context.getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(s,null,bounds);}
        if(bounds.outWidth<=0||bounds.outHeight<=0)throw new Exception("图片文件损坏或不受支持");
        BitmapFactory.Options opt=new BitmapFactory.Options();
        opt.inSampleSize=1;
        while(bounds.outWidth/opt.inSampleSize>1800 || bounds.outHeight/opt.inSampleSize>1800)opt.inSampleSize*=2;
        Bitmap bitmap;
        try(InputStream s=context.getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(s,null,opt);}
        if(bitmap==null)throw new Exception("无法解码照片");
        int rotate=0;
        try(InputStream s=context.getContentResolver().openInputStream(uri)){
            ExifInterface exif=new ExifInterface(s);
            switch(exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL)){
                case ExifInterface.ORIENTATION_ROTATE_90:rotate=90;break;
                case ExifInterface.ORIENTATION_ROTATE_180:rotate=180;break;
                case ExifInterface.ORIENTATION_ROTATE_270:rotate=270;break;
            }
        }catch(Exception ignored){}
        if(rotate!=0){Matrix matrix=new Matrix();matrix.postRotate(rotate);
            Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
            if(rotated!=bitmap)bitmap.recycle();bitmap=rotated;
        }
        File dir=new File(context.getFilesDir(),"product_photos");if(!dir.exists()&&!dir.mkdirs())throw new Exception("无法创建照片目录");
        File dest=new File(dir,UUID.randomUUID().toString()+".jpg");
        try(FileOutputStream fos=new FileOutputStream(dest)){
            if(!bitmap.compress(Bitmap.CompressFormat.JPEG,85,fos))throw new Exception("照片保存失败");
        }finally{bitmap.recycle();}
        return dest.getAbsolutePath();
    }
    public static Bitmap thumbnail(String path,int maxPixels) {
        try {
            if(path==null||path.isEmpty()||!new File(path).exists())return null;
            BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
            BitmapFactory.decodeFile(path,bounds);
            BitmapFactory.Options opt=new BitmapFactory.Options();opt.inSampleSize=1;
            while(bounds.outWidth/opt.inSampleSize>maxPixels*2 || bounds.outHeight/opt.inSampleSize>maxPixels*2)opt.inSampleSize*=2;
            return BitmapFactory.decodeFile(path,opt);
        }catch(Exception e){return null;}
    }
}
