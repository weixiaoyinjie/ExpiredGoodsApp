package com.stock.expiry;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Stores the API key encrypted under a non-exportable Android Keystore AES key. */
public class SecretStore {
    private static final String ALIAS="expiry_openai_api_key_v1";
    private final SharedPreferences prefs;
    public SecretStore(Context ctx){prefs=ctx.getSharedPreferences("local_settings",Context.MODE_PRIVATE);}
    public String model(){return prefs.getString("model","gpt-6-luna");}
    public void setModel(String s){prefs.edit().putString("model",s.trim()).apply();}
    private SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(ALIAS))return (SecretKey)ks.getKey(ALIAS,null);
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());return gen.generateKey();
    }
    public void setApiKey(String apiKey) throws Exception {
        if(apiKey==null || apiKey.trim().isEmpty()){prefs.edit().remove("api_key_cipher").remove("api_key_iv").apply();return;}
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
        prefs.edit().putString("api_key_cipher",Base64.encodeToString(c.doFinal(apiKey.trim().getBytes("UTF-8")),Base64.NO_WRAP))
                .putString("api_key_iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).apply();
    }
    public String apiKey(){
        String enc=prefs.getString("api_key_cipher",null),iv=prefs.getString("api_key_iv",null);
        if(enc==null||iv==null)return "";
        try {Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(enc,Base64.NO_WRAP)),"UTF-8");
        }catch(Exception e){return "";}
    }
}
