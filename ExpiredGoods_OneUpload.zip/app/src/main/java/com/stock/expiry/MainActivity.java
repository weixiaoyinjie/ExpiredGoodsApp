package com.stock.expiry;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int CAMERA_REQ=11, PICK_REQ=12, CSV_REQ=13;
    private static final int BG=Color.rgb(246,248,251), TEXT=Color.rgb(32,49,64), MUTED=Color.rgb(102,116,132);
    private static final int PRIMARY=Color.rgb(7,111,115), LIGHT=Color.rgb(229,245,243), WHITE=Color.WHITE;
    private final Set<Long> selected=new HashSet<>();
    private Store store;private SecretStore secrets;private LinearLayout mainArea;
    private TextView countLabel;private Button copyButton,cutButton;
    private int tab=0;private long expandedDealerId=-1;
    private String searchText="",pendingPhoto="";private File cameraFile;

    @Override public void onCreate(Bundle state){super.onCreate(state);store=new Store(this);secrets=new SecretStore(this);render();}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable bordered(int color,int stroke,int radius){GradientDrawable d=bg(color,radius);d.setStroke(dp(1),stroke);return d;}
    private TextView text(String str,int sp,boolean bold,int color){
        TextView t=new TextView(this);t.setText(str);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(dp(2),1.02f);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void pad(View v,int left,int top,int right,int bottom){v.setPadding(dp(left),dp(top),dp(right),dp(bottom));}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w==-1?-1:dp(w),h==-1?-1:h==-2?-2:dp(h));}
    private void spacer(LinearLayout parent,int height){View v=new View(this);parent.addView(v,lp(1,height));}
    private void addRule(LinearLayout parent){View v=new View(this);v.setBackgroundColor(Color.rgb(231,236,239));parent.addView(v,new LinearLayout.LayoutParams(-1,dp(1)));}
    private Button button(String s,boolean primary,Runnable action){
        Button b=new Button(this);b.setText(s);b.setTextAllCaps(false);b.setTextSize(13);b.setMinHeight(0);b.setMinimumHeight(0);
        b.setTextColor(primary?WHITE:PRIMARY);b.setBackground(bordered(primary?PRIMARY:LIGHT,primary?PRIMARY:Color.rgb(208,230,226),10));
        pad(b,9,8,9,8);b.setOnClickListener(v->action.run());return b;
    }
    private void addButton(LinearLayout row,String s,boolean primary,Runnable action){
        Button b=button(s,primary,action);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);
        p.setMargins(dp(3),0,dp(3),0);row.addView(b,p);
    }
    private LinearLayout card(LinearLayout parent){
        LinearLayout c=vertical();c.setBackground(bordered(WHITE,Color.rgb(230,235,240),14));pad(c,13,13,13,13);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));parent.addView(c,p);return c;
    }
    private void heading(LinearLayout parent,String h,String sub){TextView tv=text(h,17,true,TEXT);parent.addView(tv);if(sub!=null&&!sub.isEmpty()){TextView s=text(sub,12,false,MUTED);parent.addView(s);}}
    private EditText edit(String value,String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setTextColor(TEXT);e.setHint(hint);e.setText(value==null?"":value);return e;}
    private void labeled(LinearLayout parent,String label,View input){TextView t=text(label,12,true,MUTED);LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(-1,-2);a.topMargin=dp(8);parent.addView(t,a);parent.addView(input,new LinearLayout.LayoutParams(-1,-2));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void error(String s){new AlertDialog.Builder(this).setTitle("提示").setMessage(s).setPositiveButton("知道了",null).show();}
    private String val(EditText e){return e.getText().toString().trim();}
    private int num(String s,int defaultV){try{return Math.max(1,Integer.parseInt(s));}catch(Exception ex){return defaultV;}}
    private static String safe(String s){return s==null?"":s;}
    private static String summary(Store.Product p){return p.qty+safe(p.unit)+"  ·  "+(safe(p.spec).isEmpty()?"未填规格":p.spec)+(!safe(p.expiry).isEmpty()?"  ·  到期 "+p.expiry:"");}
    private void setTab(int tab){this.tab=tab;render();}

    private void render(){
        LinearLayout root=vertical();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout header=vertical();header.setBackgroundColor(WHITE);pad(header,17,17,17,12);root.addView(header);
        header.addView(text("过期商品 · 换货登记",21,true,TEXT));
        header.addView(text("先按商品种类与品牌归档，再分配给经销商",12,false,MUTED));
        spacer(header,13);
        LinearLayout tabs=horizontal();header.addView(tabs);
        String[] titles={"商品分类","经销商换货","设置/导出"};
        for(int i=0;i<titles.length;i++){
            final int idx=i;Button b=button(titles[i],tab==i,()->setTab(idx));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);p.setMargins(dp(2),0,dp(2),0);tabs.addView(b,p);
        }
        addRule(root);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        mainArea=vertical();pad(mainArea,14,14,14,24);scroll.addView(mainArea);
        if(tab==0)renderProducts();else if(tab==1)renderDealers();else renderSettings();
    }

    private void renderProducts(){
        List<Store.Product> all=store.products(true);
        LinearLayout actions=card(mainArea);heading(actions,"商品自动分类","拍照或从相册导入，AI 自动识别类别、品牌及规格。数量可修改。");
        spacer(actions,11);
        LinearLayout row=horizontal();actions.addView(row);
        addButton(row,"📷 拍照",true,this::capture);addButton(row,"相册导入",false,this::pickImage);
        spacer(actions,7);LinearLayout row2=horizontal();actions.addView(row2);
        addButton(row2,"＋ 手动登记",false,()->editProductDialog(null,""));
        addButton(row2,"查看经销商",false,()->setTab(1));
        if(!pendingPhoto.isEmpty()){
            spacer(actions,7);Button retry=button("继续处理上次照片",false,this::askPhotoAction);actions.addView(retry,lp(-1,42));
        }
        LinearLayout toolbar=card(mainArea);
        heading(toolbar,"待分配商品："+all.size()+" 条","按“大类 → 品牌 → 单品”排列；可勾选多个后批量转入经销商。");
        spacer(toolbar,7);
        countLabel=text("已选中 0 条",13,true,PRIMARY);toolbar.addView(countLabel);
        LinearLayout chooser=horizontal();toolbar.addView(chooser);
        copyButton=button("复制到经销商",false,()->chooseDealer(false));cutButton=button("剪切到经销商",true,()->chooseDealer(true));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(43),1);bp.setMargins(0,dp(7),dp(3),0);chooser.addView(copyButton,bp);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(43),1);cp.setMargins(dp(3),dp(7),0,0);chooser.addView(cutButton,cp);
        updateSelectionUI();
        spacer(toolbar,9);
        LinearLayout sr=horizontal();toolbar.addView(sr);
        EditText input=edit(searchText,"搜索商品 / 品牌 / 大类");
        sr.addView(input,new LinearLayout.LayoutParams(0,dp(48),1));
        Button search=button("搜索",false,()->{searchText=val(input);render();});sr.addView(search,lp(73,43));
        if(!searchText.isEmpty()){
            Button clear=button("清除搜索",false,()->{searchText="";render();});toolbar.addView(clear,lp(-1,38));
        }
        if(all.isEmpty()){LinearLayout empty=card(mainArea);empty.addView(text("暂无待分配商品。先拍一张过期商品照片。",14,false,MUTED));return;}
        Map<String,Map<String,List<Store.Product>>> groups=new LinkedHashMap<>();
        for(Store.Product p:all){
            if(!searchText.isEmpty() && !(safe(p.name)+" "+safe(p.category)+" "+safe(p.brand)+" "+safe(p.spec)).toLowerCase().contains(searchText.toLowerCase()))continue;
            groups.computeIfAbsent(p.category,k->new LinkedHashMap<>()).computeIfAbsent(p.brand,k->new ArrayList<>()).add(p);
        }
        if(groups.isEmpty()){LinearLayout empty=card(mainArea);empty.addView(text("没有符合搜索条件的商品。",14,false,MUTED));return;}
        for(Map.Entry<String,Map<String,List<Store.Product>>> category:groups.entrySet()){
            LinearLayout cl=card(mainArea);
            int total=0;for(List<Store.Product> group:category.getValue().values())total+=group.size();
            TextView categoryTitle=text("▌ "+category.getKey()+"  ·  "+total+" 条",17,true,PRIMARY);cl.addView(categoryTitle);spacer(cl,5);
            for(Map.Entry<String,List<Store.Product>> brand:category.getValue().entrySet()){
                TextView bt=text("品牌："+brand.getKey(),14,true,TEXT);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(7);p.bottomMargin=dp(5);cl.addView(bt,p);
                for(Store.Product item:brand.getValue())productRow(cl,item);
            }
        }
    }
    private void updateSelectionUI(){if(countLabel!=null)countLabel.setText("已选中 "+selected.size()+" 条");
        if(copyButton!=null)copyButton.setEnabled(!selected.isEmpty());if(cutButton!=null)cutButton.setEnabled(!selected.isEmpty());}
    private void productRow(LinearLayout parent,Store.Product p){
        addRule(parent);LinearLayout item=horizontal();pad(item,0,8,0,8);parent.addView(item);
        CheckBox check=new CheckBox(this);check.setButtonTintList(ColorStateList.valueOf(PRIMARY));check.setChecked(selected.contains(p.id));
        check.setOnCheckedChangeListener((v,checked)->{if(checked)selected.add(p.id);else selected.remove(p.id);updateSelectionUI();});item.addView(check,lp(45,46));
        ImageView image=thumb(p.photo);if(image!=null){item.addView(image,lp(63,63));image.setOnClickListener(v->showPhoto(p.photo));}
        LinearLayout info=vertical();LinearLayout.LayoutParams il=new LinearLayout.LayoutParams(0,-2,1);il.leftMargin=dp(8);item.addView(info,il);
        info.addView(text(p.name,14,true,TEXT));info.addView(text(summary(p),12,false,MUTED));
        if(!safe(p.note).isEmpty()){TextView notes=text(p.note,11,false,MUTED);notes.setMaxLines(2);info.addView(notes);}
        Button change=button("修改",false,()->editProductDialog(p,p.photo));item.addView(change,lp(61,39));
    }

    private void chooseDealer(boolean cut){
        if(selected.isEmpty()){toast("先勾选商品");return;}
        List<Store.Dealer> ds=store.dealers();
        if(ds.isEmpty()){
            new AlertDialog.Builder(this).setTitle("尚未建立经销商分类")
                    .setMessage("请先手动新增经销商，然后再剪切或复制商品。")
                    .setPositiveButton("新增经销商",(d,w)->dealerDialog(null,()->chooseDealer(cut)))
                    .setNegativeButton("取消",null).show();return;
        }
        String[] names=new String[ds.size()+1];for(int i=0;i<ds.size();i++)names[i]=ds.get(i).name;
        names[ds.size()]="＋ 新增经销商...";
        new AlertDialog.Builder(this).setTitle(cut?"剪切到哪个经销商？":"复制到哪个经销商？")
                .setMessage(cut?"剪切后将从待分配商品列表消失，但原始登记和照片保留。":"复制后原商品仍保留在分类列表，可再次分配。")
                .setItems(names,(dialog,which)->{
                    if(which==ds.size()){dealerDialog(null,()->chooseDealer(cut));return;}
                    int n=store.transfer(new ArrayList<>(selected),ds.get(which).id,cut);
                    selected.clear();toast("已"+(cut?"剪切":"复制")+" "+n+" 条到「"+ds.get(which).name+"」");render();
                }).setNegativeButton("取消",null).show();
    }

    private void renderDealers(){
        LinearLayout controls=card(mainArea);heading(controls,"手动经销商分类","你自己创建、修改经销商名称，AI 不会替你决定归属。");spacer(controls,11);
        Button newDealer=button("＋ 新建经销商分类",true,()->dealerDialog(null,null));controls.addView(newDealer,lp(-1,43));
        List<Store.Dealer> ds=store.dealers();
        if(ds.isEmpty()){LinearLayout c=card(mainArea);c.addView(text("还没有经销商。比如：Bimbo 供应商、乳制品供应商、肉制品供应商。名称可随意填写。",14,false,MUTED));return;}
        for(Store.Dealer dealer:ds){
            List<Store.Exchange> records=store.exchangeItems(dealer.id);int open=0;for(Store.Exchange e:records)if(!e.done)open++;
            LinearLayout c=card(mainArea);LinearLayout head=horizontal();c.addView(head);
            LinearLayout left=vertical();head.addView(left,new LinearLayout.LayoutParams(0,-2,1));
            left.addView(text((expandedDealerId==dealer.id?"▾  ":"▸  ")+dealer.name,16,true,TEXT));
            left.addView(text("待换 "+open+"  ·  已换 "+(records.size()-open)+"  ·  合计 "+records.size(),12,false,open>0?PRIMARY:MUTED));
            head.setOnClickListener(v->{expandedDealerId=(expandedDealerId==dealer.id?-1:dealer.id);render();});
            Button show=button(expandedDealerId==dealer.id?"收起":"查看",false,()->{expandedDealerId=(expandedDealerId==dealer.id?-1:dealer.id);render();});head.addView(show,lp(68,38));
            if(expandedDealerId!=dealer.id)continue;
            spacer(c,12);addRule(c);spacer(c,11);
            if(!safe(dealer.note).isEmpty())c.addView(text("备注："+dealer.note,12,false,MUTED));
            LinearLayout opts=horizontal();c.addView(opts);addButton(opts,"编辑经销商",false,()->dealerDialog(dealer,null));
            addButton(opts,"复制换货单",true,()->copyDealer(dealer,records));
            spacer(c,8);LinearLayout opts2=horizontal();c.addView(opts2);
            addButton(opts2,"分享清单",false,()->shareDealer(dealer,records));
            addButton(opts2,"删除经销商",false,()->confirmDeleteDealer(dealer));
            spacer(c,10);
            if(records.isEmpty()){c.addView(text("暂无换货记录。请先在“商品分类”里选择商品并转入此经销商。",13,false,MUTED));continue;}
            String last="";
            for(Store.Exchange e:records){
                String group=safe(e.category)+" / "+safe(e.brand);
                if(!last.equals(group)){TextView g=text(group,13,true,PRIMARY);LinearLayout.LayoutParams gp=lp(-1,-2);gp.topMargin=dp(9);c.addView(g,gp);last=group;}
                exchangeRow(c,e);
            }
        }
    }
    private void exchangeRow(LinearLayout parent,Store.Exchange e){
        addRule(parent);LinearLayout row=horizontal();pad(row,0,9,0,9);parent.addView(row);
        CheckBox done=new CheckBox(this);done.setButtonTintList(ColorStateList.valueOf(PRIMARY));done.setChecked(e.done);
        done.setOnCheckedChangeListener((view,checked)->{store.setDone(e.id,checked);toast(checked?"已标记为完成换货":"已恢复为待换货");});
        row.addView(done,lp(43,49));
        ImageView pic=thumb(e.photo);if(pic!=null){row.addView(pic,lp(58,58));pic.setOnClickListener(v->showPhoto(e.photo));}
        LinearLayout body=vertical();LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(8);row.addView(body,p);
        TextView name=text(e.name,14,true,e.done?MUTED:TEXT);if(e.done)name.setPaintFlags(name.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);body.addView(name);
        String meta=e.qty+safe(e.unit)+" · "+safe(e.spec)+(safe(e.expiry).isEmpty()?"":" · 到期 "+e.expiry);
        body.addView(text(meta,12,false,MUTED));
        body.addView(text(e.done?"✓ 已更换":("COPY".equals(e.mode)?"复制记录":"剪切记录"),11,false,e.done?PRIMARY:MUTED));
        Button edit=button("数量/删除",false,()->exchangeDialog(e));row.addView(edit,lp(94,40));
    }
    private void dealerDialog(Store.Dealer dealer,Runnable after){
        LinearLayout form=vertical();pad(form,20,6,20,6);
        EditText name=edit(dealer==null?"":dealer.name,"如：Bimbo 经销商");labeled(form,"经销商名称（自定义）",name);
        EditText notes=edit(dealer==null?"":dealer.note,"电话或换货备注（选填）");labeled(form,"备注",notes);
        AlertDialog alert=new AlertDialog.Builder(this).setTitle(dealer==null?"新增经销商分类":"编辑经销商")
                .setView(form).setPositiveButton("保存",null).setNegativeButton("取消",null).create();
        alert.setOnShowListener(x->alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(val(name).isEmpty()){name.setError("名称不能为空");return;}
            if(dealer==null)store.addDealer(val(name),val(notes));else store.editDealer(dealer.id,val(name),val(notes));
            alert.dismiss();render();if(after!=null)after.run();
        }));alert.show();
    }
    private void confirmDeleteDealer(Store.Dealer d){
        new AlertDialog.Builder(this).setTitle("删除经销商分类？")
                .setMessage("只有换货清单为空，才能删除经销商，避免误删。")
                .setPositiveButton("删除",(dialog,w)->{
                    if(!store.deleteDealerIfEmpty(d.id))error("此经销商还有换货记录。请先逐条移除记录（剪切记录移除后会退回商品分类）。");
                    else{expandedDealerId=-1;render();}
                }).setNegativeButton("取消",null).show();
    }
    private void exchangeDialog(Store.Exchange e){
        LinearLayout form=vertical();pad(form,18,6,18,6);
        form.addView(text(e.name+"\n"+e.category+" / "+e.brand,14,true,TEXT));
        EditText qty=edit(String.valueOf(e.qty),"数量");qty.setInputType(InputType.TYPE_CLASS_NUMBER);labeled(form,"换货数量",qty);
        new AlertDialog.Builder(this).setTitle("修改换货记录").setView(form)
                .setPositiveButton("保存数量",(d,w)->{store.changeExchangeQty(e.id,num(val(qty),e.qty));render();})
                .setNeutralButton("移除记录",(d,w)->new AlertDialog.Builder(this)
                        .setTitle("从经销商换货清单移除？")
                        .setMessage("剪切的商品会回到“商品分类”；复制的商品原本就在商品分类内。")
                        .setPositiveButton("移除",(a,b)->{store.removeExchange(e);render();})
                        .setNegativeButton("取消",null).show())
                .setNegativeButton("取消",null).show();
    }

    private String dealerText(Store.Dealer dealer,List<Store.Exchange> items){
        StringBuilder sb=new StringBuilder("【经销商换货单】"+dealer.name+"\n");
        int open=0;for(Store.Exchange e:items)if(!e.done)open++;
        sb.append("待换货：").append(open).append("条；已更换：").append(items.size()-open).append("条\n\n");
        for(Store.Exchange e:items){
            sb.append(e.done?"[✓] ":"[ ] ").append(safe(e.category)).append(" / ").append(safe(e.brand))
                    .append(" / ").append(safe(e.name)).append(" · ").append(e.qty).append(safe(e.unit));
            if(!safe(e.spec).isEmpty())sb.append(" · ").append(e.spec);
            if(!safe(e.expiry).isEmpty())sb.append(" · 到期 ").append(e.expiry);
            sb.append('\n');
        }
        return sb.toString();
    }
    private void copyDealer(Store.Dealer d,List<Store.Exchange> items){
        ClipboardManager mgr=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        mgr.setPrimaryClip(ClipData.newPlainText("经销商换货单",dealerText(d,items)));toast("已复制「"+d.name+"」的换货列表");
    }
    private void shareDealer(Store.Dealer d,List<Store.Exchange> items){
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,dealerText(d,items));
        startActivity(Intent.createChooser(send,"分享换货单"));
    }

    private void renderSettings(){
        LinearLayout settings=card(mainArea);heading(settings,"OpenAI 图片识别设置","API Key 只需填写一次。仅识别时向 OpenAI 发送照片，不会上传本地换货清单。");
        EditText key=edit("",secrets.apiKey().isEmpty()?"填写 sk-...":"密钥已保存在本机；不修改请留空");
        key.setSingleLine(true);key.setTransformationMethod(PasswordTransformationMethod.getInstance());labeled(settings,"API Key",key);
        EditText model=edit(secrets.model(),"gpt-6-luna");labeled(settings,"识别模型",model);
        spacer(settings,10);
        Button save=button("保存 API 设置",true,()->{
            try {
                if(!val(key).isEmpty())secrets.setApiKey(val(key));
                if(!val(model).isEmpty())secrets.setModel(val(model));
                key.setText("");toast("设置已保存");
            }catch(Exception ex){error("保存 API Key 失败："+ex.getMessage());}
        });settings.addView(save,lp(-1,44));
        spacer(settings,8);
        Button remove=button("清除本机 API Key",false,()->{
            new AlertDialog.Builder(this).setTitle("确认清除密钥？").setPositiveButton("清除",(d,w)->{
                try{secrets.setApiKey("");render();toast("已清除");}catch(Exception ex){error(ex.getMessage());}
            }).setNegativeButton("取消",null).show();
        });settings.addView(remove,lp(-1,40));
        LinearLayout export=card(mainArea);heading(export,"本地数据和导出","商品照片与登记保存在手机 App 私有空间。卸载 App 会删除数据，建议定期导出 CSV。");
        spacer(export,10);
        Button csv=button("导出全部登记 + 换货清单（CSV）",true,this::exportCsv);export.addView(csv,lp(-1,46));
        spacer(export,9);
        export.addView(text("说明：CSV 包含文字资料和状态，不包含图片文件。每个经销商的换货单还可直接“复制换货单”或“分享清单”。",12,false,MUTED));
        LinearLayout info=card(mainArea);heading(info,"剪切与复制的区别","");spacer(info,7);
        info.addView(text("复制：商品仍留在“商品分类”，经销商栏目新增一条换货记录。\n\n剪切：商品从待分配列表移出，转到指定经销商；底层原始登记保留。如误剪切，从经销商移除即可恢复。\n\n已更换：在经销商换货单里勾选，不会删除商品。",13,false,TEXT));
    }

    private void capture(){
        try{
            File dir=getExternalFilesDir(Environment.DIRECTORY_PICTURES);if(dir==null)throw new Exception("无法访问相机存储目录");
            if(!dir.exists()&&!dir.mkdirs())throw new Exception("无法创建拍照文件夹");
            cameraFile=File.createTempFile("expiry_photo_",".jpg",dir);
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",cameraFile);
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(i,CAMERA_REQ);
        }catch(Exception e){error("打开相机失败："+e.getMessage());}
    }
    private void pickImage(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_REQ);
    }
    private void exportCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"过期商品换货_"+new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date())+".csv");
        startActivityForResult(i,CSV_REQ);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK){if(requestCode==CAMERA_REQ&&cameraFile!=null)cameraFile.delete();return;}
        if(requestCode==CSV_REQ){if(data!=null&&data.getData()!=null)writeCsv(data.getData());return;}
        Uri u=null;
        if(requestCode==CAMERA_REQ&&cameraFile!=null)u=Uri.fromFile(cameraFile);
        else if(requestCode==PICK_REQ&&data!=null)u=data.getData();
        if(u!=null)importUri(u);
    }
    private void importUri(Uri uri){
        AlertDialog progress=new AlertDialog.Builder(this).setTitle("处理照片").setMessage("正在压缩并保存照片到手机本地...").setCancelable(false).create();progress.show();
        new Thread(()->{
            try {String path=PhotoUtil.importPhoto(this,uri);
                runOnUiThread(()->{progress.dismiss();pendingPhoto=path;askPhotoAction();});
            }catch(Exception e){runOnUiThread(()->{progress.dismiss();error("照片读取失败："+e.getMessage());});}
            finally{if(cameraFile!=null){cameraFile.delete();cameraFile=null;}}
        },"photo-import").start();
    }
    private void askPhotoAction(){
        if(pendingPhoto.isEmpty()){toast("请先拍照或导入照片");return;}
        if(!secrets.apiKey().isEmpty()){recognizePending();return;}
        new AlertDialog.Builder(this).setTitle("照片已保存")
                .setMessage("尚未填写 OpenAI API Key。可以先到设置填写，或直接手动登记商品。")
                .setPositiveButton("去设置 API",(d,w)->setTab(2))
                .setNeutralButton("手动登记",(d,w)->editProductDialog(null,pendingPhoto))
                .setNegativeButton("稍后处理",null).show();
    }
    private void recognizePending(){
        final String path=pendingPhoto;final String apiKey=secrets.apiKey();
        if(apiKey.isEmpty()){askPhotoAction();return;}
        AlertDialog progress=new AlertDialog.Builder(this).setTitle("AI 正在识别")
                .setMessage("识别大类 → 品牌 → 商品名称/规格/数量/日期\n结果可手动修改后再保存。")
                .setCancelable(false).create();progress.show();
        new Thread(()->{
            try {List<Store.Product> goods=AiClient.recognize(apiKey,secrets.model(),path);
                runOnUiThread(()->{progress.dismiss();previewRecognized(goods,path);});
            }catch(Exception e){runOnUiThread(()->{progress.dismiss();
                new AlertDialog.Builder(this).setTitle("AI 识别失败")
                        .setMessage(e.getMessage()+"\n\n照片已保存，可尝试重试或者手工登记。")
                        .setPositiveButton("重试",(d,w)->recognizePending())
                        .setNeutralButton("手动登记",(d,w)->editProductDialog(null,path))
                        .setNegativeButton("取消",null).show();
            });}
        },"openai-recognition").start();
    }

    private static final class EntryFields {
        Store.Product product;CheckBox include;EditText name,category,brand,spec,qty,unit,expiry,note;
    }
    private EntryFields makeFields(LinearLayout form,Store.Product p,boolean allowSkip){
        EntryFields f=new EntryFields();f.product=p;
        if(allowSkip){f.include=new CheckBox(this);f.include.setText("保存此商品");f.include.setTextSize(13);f.include.setButtonTintList(ColorStateList.valueOf(PRIMARY));f.include.setChecked(true);form.addView(f.include);}
        f.name=edit(safe(p.name),"产品名称");labeled(form,"产品名称",f.name);
        f.category=edit(safe(p.category),"面包 / 酸奶 / 香肠...");labeled(form,"商品大类（可改）",f.category);
        f.brand=edit(safe(p.brand),"品牌");labeled(form,"品牌分类（可改）",f.brand);
        f.spec=edit(safe(p.spec),"如 400g");labeled(form,"规格",f.spec);
        f.qty=edit(String.valueOf(Math.max(1,p.qty)),"数量");f.qty.setInputType(InputType.TYPE_CLASS_NUMBER);labeled(form,"登记数量",f.qty);
        f.unit=edit(safe(p.unit).isEmpty()?"件":p.unit,"包、盒、瓶...");labeled(form,"数量单位",f.unit);
        f.expiry=edit(safe(p.expiry),"YYYY-MM-DD / 留空");labeled(form,"到期日（不确定请留空）",f.expiry);
        f.note=edit(safe(p.note),"备注");labeled(form,"备注",f.note);
        return f;
    }
    private Store.Product collect(EntryFields f){
        Store.Product p=f.product;
        p.name=val(f.name);p.category=AiClient.normalizeCategory(val(f.category));p.brand=val(f.brand);
        p.spec=val(f.spec);p.qty=num(val(f.qty),1);p.unit=val(f.unit);p.expiry=val(f.expiry);p.note=val(f.note);
        if(p.brand.isEmpty())p.brand="未识别品牌";if(p.unit.isEmpty())p.unit="件";return p;
    }
    private void previewRecognized(List<Store.Product> goods,String photo){
        ScrollView scroll=new ScrollView(this);LinearLayout forms=vertical();pad(forms,16,6,16,14);scroll.addView(forms);
        TextView note=text("识别出 "+goods.size()+" 款商品。请核对品牌、数量、有效期；不正确的商品可取消勾选。",13,false,PRIMARY);forms.addView(note);
        ArrayList<EntryFields> fields=new ArrayList<>();
        for(int i=0;i<goods.size();i++){
            spacer(forms,12);TextView title=text("第 "+(i+1)+" 款商品",15,true,PRIMARY);forms.addView(title);
            fields.add(makeFields(forms,goods.get(i),true));spacer(forms,12);addRule(forms);
        }
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("AI 识别结果 · 确认登记")
                .setView(scroll).setPositiveButton("保存勾选商品",null)
                .setNegativeButton("取消",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int n=0;
            for(EntryFields f:fields){
                if(f.include!=null&&!f.include.isChecked())continue;
                Store.Product p=collect(f);
                if(p.name.isEmpty()){f.name.setError("商品名称不能为空");return;}
            }
            for(EntryFields f:fields){
                if(f.include!=null&&!f.include.isChecked())continue;
                Store.Product p=collect(f);p.photo=photo;store.addProduct(p);n++;
            }
            dlg.dismiss();pendingPhoto="";selected.clear();tab=0;render();toast("已保存 "+n+" 款，自动归入商品类别与品牌");
        }));dlg.show();
    }
    private void editProductDialog(Store.Product product,String photo){
        final boolean isNew=product==null;
        Store.Product p=isNew?new Store.Product():product;
        if(isNew){p.name="";p.category="其他";p.brand="";p.qty=1;p.unit="件";p.spec="";p.expiry="";p.note="";p.photo=safe(photo);}
        ScrollView scroll=new ScrollView(this);LinearLayout fields=vertical();pad(fields,18,4,18,8);scroll.addView(fields);
        EntryFields f=makeFields(fields,p,false);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(isNew?"手动登记商品":"修改商品登记")
                .setView(scroll).setPositiveButton("保存",null)
                .setNeutralButton(isNew?"取消":"删除",null).setNegativeButton("关闭",null).create();
        dlg.setOnShowListener(x->{
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                Store.Product updated=collect(f);if(updated.name.isEmpty()){f.name.setError("名称不能为空");return;}
                if(isNew){store.addProduct(updated);pendingPhoto="";}else store.editProduct(updated);
                dlg.dismiss();render();toast("商品记录已保存");
            });
            if(!isNew)dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{
                new AlertDialog.Builder(this).setTitle("删除此商品？")
                        .setMessage("有换货历史的商品不能直接删除。")
                        .setPositiveButton("删除",(d,w)->{
                            try {store.deleteProduct(p.id);selected.remove(p.id);dlg.dismiss();render();}
                            catch(Exception e){error(e.getMessage());}
                        }).setNegativeButton("取消",null).show();
            });
        });dlg.show();
    }
    private ImageView thumb(String path){
        Bitmap b=PhotoUtil.thumbnail(path,130);if(b==null)return null;
        ImageView iv=new ImageView(this);iv.setImageBitmap(b);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(bg(LIGHT,8));iv.setClipToOutline(true);return iv;
    }
    private void showPhoto(String path){
        Bitmap b=PhotoUtil.thumbnail(path,1100);if(b==null){toast("照片文件不存在");return;}
        ImageView img=new ImageView(this);img.setImageBitmap(b);img.setAdjustViewBounds(true);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);pad(img,8,8,8,8);
        new AlertDialog.Builder(this).setTitle("商品原始照片").setView(img).setPositiveButton("关闭",null).show();
    }
    private static String csvField(String s){return "\""+safe(s).replace("\"","\"\"")+"\"";}
    private void writeCsv(Uri uri){
        try(OutputStreamWriter out=new OutputStreamWriter(getContentResolver().openOutputStream(uri),StandardCharsets.UTF_8)){
            out.write('\uFEFF');out.write("记录类型,经销商,换货状态,商品大类,品牌,商品名称,规格,数量,单位,有效期,备注,操作方式\r\n");
            for(Store.Product p:store.products(false)){
                csvLine(out,Arrays.asList("原始登记","",p.status==1?"已剪切":"待分配",p.category,p.brand,p.name,p.spec,""+p.qty,p.unit,p.expiry,p.note,""));
            }
            for(Store.Dealer d:store.dealers())for(Store.Exchange e:store.exchangeItems(d.id)){
                csvLine(out,Arrays.asList("经销商换货",d.name,e.done?"已更换":"待更换",e.category,e.brand,e.name,e.spec,""+e.qty,e.unit,e.expiry,e.note,e.mode));
            }
            toast("CSV 导出成功（不含照片）");
        }catch(Exception e){error("导出失败："+e.getMessage());}
    }
    private void csvLine(OutputStreamWriter w,List<String> cells) throws Exception {
        for(int i=0;i<cells.size();i++){if(i>0)w.write(',');w.write(csvField(cells.get(i)));}w.write("\r\n");
    }
}
