GitHub Actions 重新编译 APK（诊断版 v2）

1. 在 GitHub 打开已有的 App 仓库。
2. 点击 Code -> .github -> workflows -> build-apk.yml（或原工作流文件）。
3. 点击铅笔图标，把 build-apk-v2.txt 的全部代码粘贴并保存（Commit changes）。
   也可以新建文件 .github/workflows/build-apk.yml，若已有旧的编译工作流，建议删除或禁用旧文件以避免两个任务同时运行。
4. 点击 Actions -> Build Android APK (diagnostic v2) -> Run workflow。
5. 成功后，在这次运行页面的 Artifacts 下载 android-debug-apk。
6. 如果失败，在 Artifacts 下载 build-logs，把 error-summary.txt 或 full-build.log 发给 ChatGPT。

注意：此文件只修改 GitHub 编译流程，不修复尚未提供的 Android 源代码问题。
支持在仓库内放完整 Android 工程文件，或在仓库根目录上传一个包含完整 Android 工程的 ZIP。
如果源码 ZIP 中缺少 settings.gradle / settings.gradle.kts，或源码本身存在编译错误，仍会失败。
TXT 与 YAML 文件内容相同，方便手机复制粘贴。
